import { useState } from "react"
import Image from "next/image"
import Lightbox from "./Lightbox"

export default function ProductGallery({ images }: { images: string[] }) {

  const [activeIndex, setActiveIndex] = useState(0)
  const [lightboxOpen, setLightboxOpen] = useState(false)

  if (!images || images.length === 0) {
    return (
      <div className="aspect-square bg-gray-100 flex items-center justify-center text-gray-400">
        No Image
      </div>
    )
  }

  const prev = () => {
    setActiveIndex((prev) =>
      prev === 0 ? images.length - 1 : prev - 1
    )
  }

  const next = () => {
    setActiveIndex((prev) =>
      prev === images.length - 1 ? 0 : prev + 1
    )
  }

  return (
    <div className="w-full">

      {/* MAIN IMAGE */}

      <div className="relative aspect-square bg-white border rounded-lg overflow-hidden">

        <Image
          src={images[activeIndex]}
          alt="Product image"
          fill
          sizes="(max-width:768px) 100vw, 50vw"
          className="object-contain cursor-zoom-in"
          priority
          onClick={() => setLightboxOpen(true)}
        />

        {/* PREV BUTTON */}

        {images.length > 1 && (
          <button
            onClick={prev}
            className="absolute left-3 top-1/2 -translate-y-1/2 bg-white shadow-lg w-10 h-10 rounded-full text-xl"
          >
            ‹
          </button>
        )}

        {/* NEXT BUTTON */}

        {images.length > 1 && (
          <button
            onClick={next}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-white shadow-lg w-10 h-10 rounded-full text-xl"
          >
            ›
          </button>
        )}

      </div>

      {/* THUMBNAILS */}

      {images.length > 1 && (
        <div className="flex gap-3 mt-4 overflow-x-auto">

          {images.map((img, index) => (
            <button
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`relative w-20 h-20 border rounded-md overflow-hidden ${
                index === activeIndex
                  ? "border-black"
                  : "border-gray-200"
              }`}
            >

              <Image
                src={img}
                alt="thumbnail"
                fill
                sizes="80px"
                className="object-contain"
              />

            </button>
          ))}

        </div>
      )}

      {/* LIGHTBOX */}

      <Lightbox
        open={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={images}
        activeIndex={activeIndex}
        prev={prev}
        next={next}
      />

    </div>
  )
}