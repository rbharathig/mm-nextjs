/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: false, // Disable dark mode completely
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
