import { useState, useEffect } from "react"
import type { GetServerSideProps } from "next"
import Head from "next/head"

import ProductGallery from "../../../../components/store/core/ProductGallery"
import VariantSelector from "../../../../components/store/core/VariantSelector"
import QuantitySelector from "../../../../components/store/core/QuantitySelector"
import AddToCartButton from "../../../../components/store/core/AddToCartButton"
import ProductTabs from "../../../../components/store/core/ProductTabs"
import MobileStickyCart from "../../../../components/store/core/MobileStickyCart"
import WhatsAppCTA from "../../../../components/store/core/WhatsAppCTA"
import TrustIcons from "../../../../components/store/TrustIcons"
import ProductSchema from "../../../../components/store/core/ProductSchema"
import Breadcrumb from "../../../../components/store/core/Breadcrumb"
import PreloadGallery from "../../../../components/store/core/PreloadGallery"
import ProductFAQ from "../../../../components/store/core/ProductFAQ"
import RelatedProducts from "../../../../components/store/core/RelatedProducts"
import InternalLinks from "../../../../components/store/core/InternalLinks"
import TrustBlock from "../../../../components/store/core/TrustBlock"
import { Variant } from "../../../../components/store/core/types"



type Product = {
  id: number
  name: string
  slug: string
  description: string
  short_description: string
  images: { src: string }[]
  categories: { id: number; name: string; slug: string }[]
}

type Props = {
  product: Product
  variants: Variant[]
  relatedProducts: any[]
  internalLinks: any[]
  subcategory: string
}

export default function ProductPage({
  product,
  variants,
  relatedProducts,
  internalLinks,
  subcategory
}: Props) {

  const [variant, setVariant] = useState<Variant>(variants[0])
  const [quantity, setQuantity] = useState(1)

  const images =
    variant.image
      ? [variant.image]
      : product.images.map((img) => img.src)

  const productFaqs = [
    {
      question: "Which shruthi is best for beginners?",
      answer:
        "Most beginners start with E or F shruthi Carnatic flute because it is easier to handle and produce sound."
    },
    {
      question: "Is this flute professionally tuned?",
      answer:
        "Yes. Every flute is hand tuned by experienced craftsmen to ensure accurate pitch."
    },
    {
      question: "Do you ship across India?",
      answer:
        "Yes. We ship safely packed flutes across India through reliable courier partners."
    }
  ]

  return (
    <>
      <Head>
        <title>{product.name} | MusicMaster</title>
        <meta
          name="description"
          content={product.short_description.replace(/<[^>]+>/g, "")}
        />
      </Head>

      <ProductSchema
        name={product.name}
        description={product.short_description}
        image={images[0]}
        variants={variants}
        url={`https://musicmaster.in/store/flute/${subcategory}/${product.slug}`}
      />

      <PreloadGallery images={images} />

      <main className="max-w-6xl mx-auto px-4 pt-24 pb-16">

        <Breadcrumb
          category="flute"
          subcategory={subcategory}
          product={product.name}
        />

        <div className="grid lg:grid-cols-2 gap-10">

          {/* Gallery */}

          <ProductGallery images={images} />

          {/* Product Details */}

          <div>

            <h1 className="text-3xl font-semibold mb-3">
              {product.name}
            </h1>

            <div className="text-gray-600 mb-6">
              ₹{variant.price}
              {variant.onSale && (
                <span className="ml-2 line-through text-gray-400">
                  ₹{variant.regularPrice}
                </span>
              )}
            </div>

            <VariantSelector
              variations={variants}
              selected={variant}
              setSelected={setVariant}
            />

            <div className="mt-6 flex items-center gap-4">

              <QuantitySelector
                qty={quantity}
                setQty={setQuantity}
              />

              <AddToCartButton
                url={`/store/flute/${subcategory}/${product.slug}`}
                disabled={variant.stockStatus === 'outofstock'}
              />

            </div>

            <TrustBlock />

            <TrustIcons />

            <WhatsAppCTA />

          </div>

        </div>

        {/* Tabs */}

        <div className="mt-16">

          <ProductTabs
            product={product}
          />

        </div>

        {/* FAQ */}

        <ProductFAQ faqs={productFaqs} />

        {/* Related Products */}

        <RelatedProducts
          products={relatedProducts}
          category="flute"
          subcategory={subcategory}
        />

        {/* Internal Linking */}

        <InternalLinks
          items={internalLinks}
          category="flute"
          subcategory={subcategory}
        />

      </main>

      {/* Mobile Sticky Cart */}

      <MobileStickyCart
        variant={variant}
        quantity={quantity}
        setQuantity={setQuantity}
        productId={product.id}
      />

    </>
  )
}

export const getServerSideProps: GetServerSideProps = async (context) => {

  const { slug, subcategory } = context.params as any

  const api = process.env.WOO_API

  const productRes = await fetch(`${api}/products?slug=${slug}`)
  const productData = await productRes.json()

  if (!productData || productData.length === 0) {
    return { notFound: true }
  }

  const product = productData[0]

  const varRes = await fetch(`${api}/products/${product.id}/variations`)
  const variations = await varRes.json()

  const variants = variations.map((v: any) => ({
    id: v.id,
    label: v.attributes?.[0]?.option || "Variant",
    price: parseFloat(v.price),
    regularPrice: parseFloat(v.regular_price),
    onSale: v.on_sale,
    stockStatus: v.stock_status,
    description: v.description,
    image: v.image?.src
  }))

  const relatedRes = await fetch(
    `${api}/products?category=${product.categories[0].id}&per_page=4`
  )

  const relatedProducts = await relatedRes.json()

  const linkRes = await fetch(
    `${api}/products?category=${product.categories[0].id}&per_page=12`
  )

  const linkProducts = await linkRes.json()

  const internalLinks = linkProducts
    .filter((p: any) => p.slug !== product.slug)
    .slice(0, 9)
    .map((p: any) => ({
      slug: p.slug,
      title: p.name
    }))

  return {
    props: {
      product,
      variants,
      relatedProducts,
      internalLinks,
      subcategory
    }
  }
}